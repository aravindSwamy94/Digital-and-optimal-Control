
void VL53L0X_Init(void);
void VL53L0X_Read(int* pfData);
