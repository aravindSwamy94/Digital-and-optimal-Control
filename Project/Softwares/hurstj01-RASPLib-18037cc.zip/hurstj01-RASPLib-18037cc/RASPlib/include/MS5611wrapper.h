

void MS5611Baro_Init(void);
void MS5611Baro_Read(float* pfData);
void MS5611Baro_ReadRAW(float* pfData);
void MS5611Baro_ReadALT(float* pfData);
void MS5611Baro_ReadPT(float* pfData);