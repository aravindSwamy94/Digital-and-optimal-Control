

void MPU9250_Init(void);
void MPU9250_ReadRAW(int* pfData);
void MPU9250_Read(float* pfData);
