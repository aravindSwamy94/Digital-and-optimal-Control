clc;

Ad =[]