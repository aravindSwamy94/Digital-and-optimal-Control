clc;
Nxd=[0;0;0;0];
Nud=(1-Ad+Bd*Kd)/([1 0 0 0]*Bd);