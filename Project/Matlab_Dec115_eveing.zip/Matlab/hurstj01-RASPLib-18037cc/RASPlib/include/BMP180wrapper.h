

void BMP180_Init(void);
void BMP180_Read(float* pfData);
