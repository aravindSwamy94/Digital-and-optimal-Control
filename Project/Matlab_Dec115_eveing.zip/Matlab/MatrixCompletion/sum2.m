function Y=sum2(X);
Y=sum(X(:));
