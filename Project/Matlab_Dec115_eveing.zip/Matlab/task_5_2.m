clc;
Co = [B A*B A^2*B A^3*B ];
Ob = [C C*A C*A^2 C*A^3 ]';
